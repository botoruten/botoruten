<?php
//Discuz! cache file, DO NOT modify me!
//Identify: 20bb191a08cbb00126c7ec18c663fcc5

$adminextend = array (
  0 => 'cloud.php',
);
?>