<?php
//Discuz! cache file, DO NOT modify me!
//Identify: 48044ef2191f111dd2eba8e017ae49f9

$pluginsetting = array (
);
?>