<?PHP exit;?>	1385036565	admin	1	::1	cloudaddons	GET={extra=ac=tour&amp;view=installed; }; POST={};
<?PHP exit;?>	1385036567	admin	1	::1	cloudaddons	GET={frames=yes; extra=ac=tour&amp;view=installed; }; POST={};
<?PHP exit;?>	1385036570	admin	1	::1	cloudaddons	GET={extra=ac=tour&amp;view=installed; }; POST={};
